The only argument that the program needs, is the name of the input file, whose first line contains the number corresponding to the 
method to be used and the subsequent lines contain the maze.

The program can be run as:
python3 1.py <inputfile>

<inputfile> should be the name of the input file

It should be of the following format:
<algorithm-code>
<maze>

Algorithm Codes are as follows:
0 - BFS
1 - DFS
2 - DFID